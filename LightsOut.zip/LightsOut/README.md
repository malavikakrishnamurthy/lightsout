Please put hw5 files in this directory.

- Used to find out how to change timezone in Django: https://docs.djangoproject.com/en/3.1/topics/i18n/timezones/
- Used to find out how to re-order objects in a QuerySet: https://stackoverflow.com/questions/9355660/getting-objects-all-reverse-or-descending-order
- Used to know built in date formatting options: https://docs.djangoproject.com/en/3.1/ref/templates/builtins/#date
- Used to help structure code and understand Model objects/images: 
    - https://github.com/cmu-webapps/models-example
    - https://github.com/cmu-webapps/images-example
    - Also, re-watched lectures