from django.apps import AppConfig


class SocialnetworkConfig(AppConfig):
    name = 'socialnetwork'
