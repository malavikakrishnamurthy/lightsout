from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, default=None, on_delete=models.PROTECT)
    following = models.ManyToManyField('self', symmetrical=False, related_name="followers", blank=True)
    profile_picture = models.FileField(blank=True)
    content_type = models.CharField(max_length=50, default="")
    bio_input_text = models.CharField(max_length=300, blank=True)

    def __str__(self):
        return 'bio_input_text: ' + str(self.bio_input_text)

class Post(models.Model):
    text = models.CharField(max_length=300, default="")
    profile = models.ForeignKey(Profile, default=None, on_delete=models.PROTECT)
    date_time = models.DateTimeField()

    def __str__(self):
        return str(self.text)