// Generate a new random MQTT client id on each page load
var MQTT_CLIENT_ID = "iot_web_"+Math.floor((1 + Math.random()) * 0x10000000000).toString(16);

// Create a MQTT client instance
// var MQTT_CLIENT = new Paho.MQTT.Client("172.26.161.183", 1883, "/ws", MQTT_CLIENT_ID);
var MQTT_CLIENT = new Paho.MQTT.Client("172.26.161.183", 8883, "/ws", MQTT_CLIENT_ID);
// Tell the client instance to connect to the MQTT broker
MQTT_CLIENT.connect({ onSuccess: myClientConnected });

// This is the function which handles button clicks
function myButtonWasClicked() {
    alert("Beginning of button click");
    // create a new MQTT message with a specific payload
    var mqttMessage = new Paho.MQTT.Message("STATION:ON:1");
    
    // Set the topic it should be published to
    mqttMessage.destinationName = "pir/data/web";
    
    // Publish the message
    MQTT_CLIENT.send(mqttMessage);
    alert("Finished publishing message");
  }

// This is the function which handles button clicks
function myButtonWasClicked1() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("STATION:ON:2");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles button clicks
function myButtonWasClicked2() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("STATION:ON:3");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles button clicks
function myButtonWasClicked3() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("STATION:ON:4");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles button clicks
function allLightsOn() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("STATION:ON:5");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles button clicks
function microphonesOff() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("Turn off microphones");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles button clicks
function pirsOff() {
  alert("Beginning of button click");
  // create a new MQTT message with a specific payload
  var mqttMessage = new Paho.MQTT.Message("Turn off pirs");
  
  // Set the topic it should be published to
  mqttMessage.destinationName = "pir/data/web";
  
  // Publish the message
  MQTT_CLIENT.send(mqttMessage);
  alert("Finished publishing message");
}

// This is the function which handles subscribing to topics after a connection is made
function myClientConnected() {
    alert("In connect function");
    // Subscribe to whichever topic you are reading from
    MQTT_CLIENT.subscribe("pir/data/baseStation");
    alert("Subscribed to topic");
  }

// This is the function which handles received messages
function myMessageArrived(message) {
    alert("Message Arrived");
    // Get the payload
    var messageBody = message.payloadString;
  
    // Create a new HTML element wrapping the message payload
    var messageHTML = $("<p>"+messageBody+"</p>");
  
    // Insert it inside the ```id=updateMe``` element above everything else that is there 
    $("#updateMe").prepend(messageHTML);
  };
  
  // Tell MQTT_CLIENT to call myMessageArrived(message) each time a new message arrives
  MQTT_CLIENT.onMessageArrived = myMessageArrived;