from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from socialnetwork.models import Post, Profile
import datetime

from django.utils import timezone
from socialnetwork.forms import LoginForm, RegisterForm, EditProfileForm

def login_action(request):
    context = {}
    if request.method == 'GET':
        context = {'form': LoginForm()}
        return render(request, 'socialnetwork/login.html', context)

    form = LoginForm(request.POST)
    context['form'] = form
    if not form.is_valid():
        return render(request, 'socialnetwork/login.html', context)

    new_user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password'])

    login(request, new_user)
    return redirect(reverse('global_stream'))
    # return render(request, 'socialnetwork/globalstream.html', context)

def logout_action(request):
    logout(request)
    return redirect(reverse('login'))

def create_profile(new_user, context):
    new_profile = Profile(user=new_user)
    new_profile.save()
    context['profile'] = new_profile

def register_action(request):
    context = {}

    # Just display the registration form if this is a GET request.
    if request.method == 'GET':
        context['form'] = RegisterForm()
        return render(request, 'socialnetwork/register.html', context)

    # Creates a bound form from the request POST parameters and makes the
    # form available in the request context dictionary.
    form = RegisterForm(request.POST)
    context['form'] = form

    # Validates the form.
    if not form.is_valid():
        return render(request, 'socialnetwork/register.html', context)

    # At this point, the form data is valid.  Register and login the user.
    new_user = User.objects.create_user(username=form.cleaned_data['username'],
                                        password=form.cleaned_data['password'],
                                        email=form.cleaned_data['email'],
                                        first_name=form.cleaned_data['first_name'],
                                        last_name=form.cleaned_data['last_name'])
    new_user.save()
    create_profile(new_user, context)
    new_user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password'])

    login(request, new_user)
    return redirect(reverse('global_stream'))

def generate_posts(request, context, stream_type):
    posts = []
    # loops through elements in reverse based on date_time parameter
    for post in Post.objects.order_by("date_time").reverse():
        # global stream or follower stream and following
        if stream_type == 'global_stream' or (post.profile in request.user.profile.following.all()):
            posts.append(post)

    context['posts'] = posts

def show_profile_picture_action(request, id):
    picture = get_object_or_404(Profile, id=id)
    if not picture.profile_picture:
        raise Http404
    return HttpResponse(picture.profile_picture, content_type=picture.content_type)

def edit_profile_action(request):
    # TODO: add bio and picture? to profile model, use modelForm created
    context = {}
    if user_exists(request) and request.method == "POST":
        profile = request.user.profile
        edited_profile_form = EditProfileForm(request.POST, request.FILES, instance=profile)
        if not edited_profile_form.is_valid():
            context['edit_profile_form'] = edited_profile_form
        else:
            if 'profile_picture' in edited_profile_form.cleaned_data:
                profile_picture = edited_profile_form.cleaned_data['profile_picture']
                profile.content_type = profile_picture.content_type
                edited_profile_form.content_type = profile_picture.content_type
                edited_profile_form.save()
                profile.save()
        profile.save()
    return redirect(reverse('profile'))

def follow_action(request, id):
    if user_exists(request) and other_profile_exists(id):
        other_profile = Profile.objects.get(id=id)
        current_profile = request.user.profile
        if other_profile not in current_profile.following.all():
            current_profile.following.add(other_profile)
    return other_profile_action(request, other_profile.id)


def unfollow_action(request, id):
    if user_exists(request) and other_profile_exists(id):
        other_profile = Profile.objects.get(id=id)
        current_profile = request.user.profile
        if other_profile in current_profile.following.all():
            current_profile.following.remove(other_profile)
    return other_profile_action(request, other_profile.id)

def user_exists(request):
    try:
        if request.user.profile:
            return True
    except AttributeError:
        return False

def create_post(request):
    # may need to check for empty submission
    if user_exists(request):
        if 'post' in request.POST:
            # date_time = datetime.datetime.strftime(timezone.now(), '%m/%d/%Y %I:%M%p')
            new_post = Post(text=request.POST['post'], profile=request.user.profile,
                            date_time=timezone.now())
            new_post.save()
    return redirect(reverse('global_stream'))


@login_required
def global_stream_action(request):
    context = {}
    if request.method == 'GET':
        generate_posts(request, context, 'global_stream')
        return render(request, 'socialnetwork/globalstream.html', context)

    generate_posts(request, context, 'global_stream')
    return render(request, 'socialnetwork/globalstream.html', context)

@login_required
def controls_action(request):
    context = {}
    if request.method == 'GET':
        generate_posts(request, context, 'global_stream')
        return render(request, 'socialnetwork/controls.html', context)

@login_required
def follower_stream_action(request):
    context = {}
    generate_posts(request, context, 'follower_stream')
    if request.method == 'GET':
        return render(request, 'socialnetwork/followerstream.html', context)

@login_required
def profile_action(request):
    if user_exists(request):
        profile = request.user.profile
        context = {'edit_profile_form': EditProfileForm(initial={'bio_input_text': profile.bio_input_text})}
    return render(request, 'socialnetwork/profile.html', context)

def other_user_exists(id):
    return User.objects.filter(id=id).count() > 0

def other_profile_exists(id):
    return Profile.objects.filter(id=id).count() > 0

@login_required
def other_profile_action(request, id):
    context = {}
    if other_profile_exists(id):
        other_profile = Profile.objects.get(id=id)
        context['other_profile'] = other_profile
        if other_profile in request.user.profile.following.all():
            context['follow'] = True
        else:
            context['unfollow'] = True
    else:
        context['error'] = 'Invalid other user'
    if request.method == 'GET':
        return render(request, 'socialnetwork/otherprofile.html', context)
